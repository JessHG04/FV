rmdir -r -f build
cmake -H. -Bbuild