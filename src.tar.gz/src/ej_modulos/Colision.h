#pragma once
#include <SFML/Graphics.hpp>

class Colision{
    public:
    
    private:

};